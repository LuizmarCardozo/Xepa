const Components = {
  bottomNav(active) {
    if (window.Auth?.user?.type === "comerciante") {
      const activeTab =
        active === "minhasOfertas" || active === "ofertas"
          ? "products"
          : active === "perfil"
            ? "stall"
            : active === "carteira" || active === "resgatar"
              ? "wallet"
              : "home";
      return `
        <nav class="bottom-nav wallet-nav" aria-label="Navegação da banca">
          <button class="nav-item ${activeTab === "home" ? "active" : ""}" onclick="Router.go('home')" aria-label="Início">
            <img src="assets/nav-inicio.svg" alt=""><span>Início</span>
          </button>
          <button class="nav-item ${activeTab === "products" ? "active" : ""}" onclick="Router.goOffers()" aria-label="Produtos">
            <img src="assets/nav-produtos.svg" alt=""><span>Produtos</span>
          </button>
          <button class="nav-item ${activeTab === "stall" ? "active" : ""}" onclick="Router.go('perfil')" aria-label="Banca">
            <img src="assets/nav-banca.svg" alt=""><span>Banca</span>
          </button>
          <button class="nav-item ${activeTab === "wallet" ? "active" : ""}" onclick="Router.go('carteira')" aria-label="Xepa pay">
            <img src="assets/nav-xepapay.svg" alt=""><span>Xepa pay</span>
          </button>
        </nav>`;
    }

    const activeTab = active === "feira" ? "home" : active;
    return `
      <nav class="bottom-nav buyer-bottom-nav" aria-label="Navegação principal">
        <button class="nav-item ${activeTab === "home" ? "active" : ""}" onclick="Router.go('home')" aria-label="Feira">
          <span class="nav-icon-wrap"><img src="assets/icone%20feira.png" alt="" /></span>
          <span class="nav-label">Início</span>
        </button>
        <button class="nav-item ${activeTab === "ofertas" ? "active" : ""}" onclick="Router.goOffers()" aria-label="Ofertas">
          <span class="nav-icon-wrap"><img src="assets/icone%20ofertas.png" alt="" /></span>
          <span class="nav-label">Ofertas</span>
        </button>
        <button class="nav-item ${activeTab === "pedidos" ? "active" : ""}" onclick="Router.go('pedidos')" aria-label="Pedidos">
          <span class="nav-icon-wrap"><img src="assets/icone%20pedidos.png" alt="" /></span>
          <span class="nav-label">Pedidos</span>
        </button>
        <button class="nav-item ${activeTab === "perfil" ? "active" : ""}" onclick="Router.go('perfil')" aria-label="Perfil">
          <span class="nav-icon-wrap"><img src="assets/icoen%20perfil.png" alt="" /></span>
          <span class="nav-label">Perfil</span>
        </button>
      </nav>`;
  },
};

window.Components = Components;

function syncMobileNavigationViewport() {
  const viewport = window.visualViewport;
  // clientHeight do documento = altura do layout viewport. Se o WebView
  // redimensionar o layout com o teclado, o inset é 0 (o menu já sobe junto);
  // se só o visual viewport encolher, o inset empurra o menu para cima.
  const layoutHeight =
    document.documentElement.clientHeight || window.innerHeight;
  const inset = viewport
    ? Math.max(
        0,
        Math.round(layoutHeight - viewport.height - viewport.offsetTop),
      )
    : 0;
  document.documentElement.style.setProperty(
    "--xepa-keyboard-inset",
    `${inset}px`,
  );
}

// Move o menu para o <body>: ancestrais com transform/animation/filter
// quebram o position: fixed e fazem o menu sumir ao rolar ou abrir o teclado.
function ensureBottomNavMounted() {
  document.querySelectorAll(".bottom-nav").forEach((nav) => {
    if (nav.parentElement !== document.body) {
      document.body.appendChild(nav);
    }
    if (nav.hidden) nav.hidden = false;
    if (nav.style.display === "none") nav.style.removeProperty("display");
    if (nav.style.visibility === "hidden") {
      nav.style.removeProperty("visibility");
    }
    if (nav.style.opacity === "0") nav.style.removeProperty("opacity");
  });
}

function refreshNavigation() {
  syncMobileNavigationViewport();
  ensureBottomNavMounted();
}

if (window.visualViewport) {
  window.visualViewport.addEventListener("resize", refreshNavigation);
  window.visualViewport.addEventListener("scroll", refreshNavigation);
}
window.addEventListener("resize", refreshNavigation);
window.addEventListener("orientationchange", () =>
  setTimeout(refreshNavigation, 300),
);
window.addEventListener("scroll", syncMobileNavigationViewport, {
  passive: true,
});

// Teclado abrindo/fechando: a animação leva tempo, então reajusta algumas vezes.
["focusin", "focusout"].forEach((evt) => {
  document.addEventListener(evt, () => {
    [0, 100, 300, 600].forEach((t) => setTimeout(refreshNavigation, t));
  });
});

// Sempre que o Router renderizar uma tela nova, reposiciona o menu.
const navObserver = new MutationObserver(() => ensureBottomNavMounted());
function startNavObserver() {
  navObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["hidden", "style", "class"],
  });
  refreshNavigation();
}
if (document.body) {
  startNavObserver();
} else {
  document.addEventListener("DOMContentLoaded", startNavObserver);
}
